export const signInUserData = [
    {
        id: '21',
        avatar: '/img/avatars/thumb-1.jpg',
        userName: 'Charlie Howard',
        email: 'user1@themenate.net',
        password: '2005ipo'
    }
]